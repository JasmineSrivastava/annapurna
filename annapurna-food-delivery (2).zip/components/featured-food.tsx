"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, MapPin, Star, Plus, Flame, ArrowRight, Check } from "lucide-react"
import Link from "next/link"
import { useCartStore } from "@/lib/cart-store"
import { useToast } from "@/hooks/use-toast"

interface FoodItem {
  id: string
  name: string
  hotel_name: string
  original_price: number
  discounted_price: number
  image_url: string
  category: string
  cuisine: string
  city: string
  expiry_time: string
  rating: number
  distance: string
  description: string
}

export default function FeaturedFood() {
  const [foodItems, setFoodItems] = useState<FoodItem[]>([])
  const [loading, setLoading] = useState(true)
  const [addedItems, setAddedItems] = useState<Set<string>>(new Set())
  const addItem = useCartStore((state) => state.addItem)
  const { toast } = useToast()

  useEffect(() => {
    fetchFeaturedFood()
  }, [])

  const fetchFeaturedFood = async () => {
    try {
      const response = await fetch("/api/food-items/punjab")
      const data = await response.json()

      if (data.success) {
        setFoodItems(data.foodItems.slice(0, 6))
      }
      setLoading(false)
    } catch (error) {
      console.error("Error fetching food items:", error)
      setLoading(false)
    }
  }

  const handleAddToCart = (item: FoodItem) => {
    addItem({
      id: item.id,
      name: item.name,
      hotel_name: item.hotel_name,
      price: item.discounted_price,
      original_price: item.original_price,
      image_url: item.image_url,
    })

    setAddedItems((prev) => new Set(prev).add(item.id))

    toast({
      title: "Added to Cart!",
      description: `${item.name} has been added to your cart.`,
    })

    // Reset the added state after 2 seconds
    setTimeout(() => {
      setAddedItems((prev) => {
        const newSet = new Set(prev)
        newSet.delete(item.id)
        return newSet
      })
    }, 2000)
  }

  const calculateDiscount = (original: number, discounted: number) => {
    return Math.round(((original - discounted) / original) * 100)
  }

  if (loading) {
    return (
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-64 mx-auto mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-96 mx-auto"></div>
            </div>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-20 relative overflow-hidden bg-white">
      {/* Subtle background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23f97316' fillOpacity='0.1'%3E%3Ccircle cx='30' cy='30' r='4'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        ></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-orange-100 text-orange-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Flame className="h-4 w-4" />
            Fresh from Punjab Hotels
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Authentic Punjabi Cuisine & More</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover delicious food from top hotels across Punjab - from traditional Punjabi dishes to international
            cuisine
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {foodItems.map((item) => (
            <Card
              key={item.id}
              className="overflow-hidden hover:shadow-xl transition-all duration-300 group border-0 shadow-lg bg-white/80 backdrop-blur-sm"
            >
              <div className="relative">
                <img
                  src={item.image_url || "/placeholder.svg"}
                  alt={item.name}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <Badge className="absolute top-3 left-3 bg-green-600 hover:bg-green-700 shadow-lg">
                  {calculateDiscount(item.original_price, item.discounted_price)}% OFF
                </Badge>
                <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-full text-sm font-medium text-red-600 flex items-center gap-1 shadow-lg">
                  <Clock className="h-3 w-3" />
                  {item.expiry_time}
                </div>
                <div className="absolute bottom-3 left-3 bg-orange-600 text-white px-2 py-1 rounded-full text-xs font-medium shadow-lg">
                  {item.city}
                </div>
              </div>

              <CardContent className="p-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-bold text-lg text-gray-900 group-hover:text-orange-600 transition-colors">
                      {item.name}
                    </h3>
                    <p className="text-gray-600 text-sm flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      {item.hotel_name}
                    </p>
                    <p className="text-gray-500 text-xs mt-1 line-clamp-2">{item.description}</p>
                  </div>

                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span>{item.rating}</span>
                    </div>
                    <span>{item.distance}</span>
                    <Badge variant="secondary" className="text-xs">
                      {item.cuisine}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-green-600">₹{item.discounted_price}</span>
                        <span className="text-sm text-gray-500 line-through">₹{item.original_price}</span>
                      </div>
                      <p className="text-xs text-gray-600">Save ₹{item.original_price - item.discounted_price}</p>
                    </div>

                    <Button
                      size="sm"
                      className={`${addedItems.has(item.id) ? "bg-green-600 hover:bg-green-700" : "bg-orange-600 hover:bg-orange-700"} transition-colors shadow-lg`}
                      onClick={() => handleAddToCart(item)}
                    >
                      {addedItems.has(item.id) ? (
                        <>
                          <Check className="h-4 w-4 mr-1" />
                          Added
                        </>
                      ) : (
                        <>
                          <Plus className="h-4 w-4 mr-1" />
                          Add
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button size="lg" asChild className="bg-orange-600 hover:bg-orange-700 shadow-xl">
            <Link href="/browse">
              Explore All Punjab Hotels
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
