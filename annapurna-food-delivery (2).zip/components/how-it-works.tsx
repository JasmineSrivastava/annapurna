import { Card, CardContent } from "@/components/ui/card"
import { Search, ShoppingBag, Truck } from "lucide-react"

const steps = [
  {
    icon: Search,
    title: "Browse Available Food",
    description: "Explore fresh food options from partner hotels in your area",
    step: "01",
  },
  {
    icon: ShoppingBag,
    title: "Place Your Order",
    description: "Select items, add to cart, and complete your secure payment",
    step: "02",
  },
  {
    icon: Truck,
    title: "Pickup or Delivery",
    description: "Choose convenient pickup or get it delivered to your doorstep",
    step: "03",
  },
]

export default function HowItWorks() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Getting delicious, affordable food while reducing waste is simple
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <Card key={index} className="relative border-0 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-orange-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold">
                    {step.step}
                  </div>
                </div>
                <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 mt-4">
                  <step.icon className="h-8 w-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-semibold mb-4">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
