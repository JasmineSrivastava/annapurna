"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Leaf, Users, Heart, Award, TrendingUp, Globe } from "lucide-react"
import Link from "next/link"

const impactStats = [
  {
    icon: Leaf,
    title: "Environmental Impact",
    stats: [
      { label: "Food Waste Reduced", value: "12.5 Tons", description: "Equivalent to 50,000 meals saved" },
      { label: "CO2 Emissions Saved", value: "25 Tons", description: "Reduced carbon footprint" },
      { label: "Water Saved", value: "2.5M Liters", description: "Through reduced food waste" },
    ],
    image: "/images/food-waste-reduction.jpg",
    color: "green",
  },
  {
    icon: Users,
    title: "Community Impact",
    stats: [
      { label: "Customers Served", value: "45,000+", description: "Across Punjab and North India" },
      { label: "Meals Donated", value: "15,000+", description: "To underprivileged communities" },
      { label: "Jobs Created", value: "500+", description: "Direct and indirect employment" },
    ],
    image: "/images/happy-customers.jpg",
    color: "blue",
  },
  {
    icon: Heart,
    title: "Social Impact",
    stats: [
      { label: "Money Saved", value: "₹25 Lakh", description: "By customers through discounts" },
      { label: "Hotel Revenue", value: "₹15 Lakh", description: "Additional income for partners" },
      { label: "Community Programs", value: "25+", description: "Food distribution initiatives" },
    ],
    image: "/images/community-impact.jpg",
    color: "purple",
  },
]

const achievements = [
  {
    icon: Award,
    title: "Sustainability Award 2024",
    description: "Recognized by Punjab Government for environmental impact",
    date: "March 2024",
  },
  {
    icon: TrendingUp,
    title: "50% Growth in Food Recovery",
    description: "Increased food waste reduction by 50% in the last year",
    date: "December 2023",
  },
  {
    icon: Globe,
    title: "Expanded to 5 Cities",
    description: "Now serving customers across Punjab and Haryana",
    date: "January 2024",
  },
]

export default function ImpactContent() {
  return (
    <div className="py-16">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Our Impact Story</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Every order on ANNAPURNA creates a ripple effect of positive change. See how we're transforming food waste
            into community impact across Punjab.
          </p>
          <div className="flex justify-center">
            <img
              src="/images/community-impact.jpg"
              alt="Our Impact"
              className="w-full max-w-2xl rounded-2xl shadow-lg"
            />
          </div>
        </div>

        {/* Impact Categories */}
        <div className="space-y-16 mb-20">
          {impactStats.map((category, index) => (
            <div
              key={index}
              className={`grid lg:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? "lg:grid-flow-col-dense" : ""}`}
            >
              <div className={`space-y-6 ${index % 2 === 1 ? "lg:col-start-2" : ""}`}>
                <div className="flex items-center gap-4 mb-6">
                  <div className={`bg-${category.color}-100 w-16 h-16 rounded-full flex items-center justify-center`}>
                    <category.icon className={`h-8 w-8 text-${category.color}-600`} />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">{category.title}</h2>
                </div>

                <div className="grid gap-6">
                  {category.stats.map((stat, statIndex) => (
                    <Card key={statIndex} className="border-l-4 border-l-orange-600">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-semibold text-lg text-gray-900">{stat.label}</h3>
                            <p className="text-gray-600 text-sm mt-1">{stat.description}</p>
                          </div>
                          <Badge
                            variant="secondary"
                            className={`text-${category.color}-600 bg-${category.color}-100 text-xl font-bold px-4 py-2`}
                          >
                            {stat.value}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              <div className={`${index % 2 === 1 ? "lg:col-start-1" : ""}`}>
                <Card className="overflow-hidden shadow-xl">
                  <img
                    src={category.image || "/placeholder.svg"}
                    alt={category.title}
                    className="w-full h-96 object-cover"
                  />
                </Card>
              </div>
            </div>
          ))}
        </div>

        {/* Achievements */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Recent Achievements</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {achievements.map((achievement, index) => (
              <Card key={index} className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-8">
                  <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                    <achievement.icon className="h-8 w-8 text-orange-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-4">{achievement.title}</h3>
                  <p className="text-gray-600 mb-4">{achievement.description}</p>
                  <Badge variant="outline">{achievement.date}</Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Future Goals */}
        <div className="bg-gradient-to-r from-orange-600 to-red-600 rounded-2xl p-12 text-white text-center">
          <h2 className="text-3xl font-bold mb-6">Our 2024 Goals</h2>
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="text-4xl font-bold mb-2">100K</div>
              <div className="text-orange-100">Customers Served</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">50 Tons</div>
              <div className="text-orange-100">Food Waste Reduced</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">10 Cities</div>
              <div className="text-orange-100">Expansion Target</div>
            </div>
          </div>
          <p className="text-xl text-orange-100 mb-8 max-w-2xl mx-auto">
            Join us in creating a more sustainable future. Every order makes a difference.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/browse">Start Making Impact</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-orange-600"
              asChild
            >
              <Link href="/signup">Join Our Mission</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
