"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Leaf, Users, Utensils, TrendingUp, Heart, Award } from "lucide-react"
import Link from "next/link"

export default function Stats() {
  const [stats, setStats] = useState({
    foodSaved: 0,
    customers: 0,
    hotels: 0,
    moneySaved: 0,
  })

  useEffect(() => {
    // Animate numbers
    const timer = setTimeout(() => {
      setStats({
        foodSaved: 12500, // 12.5 tons
        customers: 45000,
        hotels: 350,
        moneySaved: 2500000, // 25 lakhs
      })
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  const statsData = [
    {
      icon: Leaf,
      value: `${(stats.foodSaved / 1000).toFixed(1)} Tons`,
      label: "Food Saved from Waste",
      color: "text-green-600",
      bgColor: "bg-green-100",
      description: "Equivalent to 50,000 meals",
      image: "/images/food-waste-reduction.jpg",
    },
    {
      icon: Users,
      value: `${(stats.customers / 1000).toFixed(0)}K+`,
      label: "Happy Customers",
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      description: "Across Punjab & North India",
      image: "/images/happy-customers.jpg",
    },
    {
      icon: Utensils,
      value: `${stats.hotels}+`,
      label: "Partner Hotels",
      color: "text-orange-600",
      bgColor: "bg-orange-100",
      description: "Premium hotels & restaurants",
      image: "/images/hotel-partnership.jpg",
    },
    {
      icon: TrendingUp,
      value: `₹${(stats.moneySaved / 100000).toFixed(0)} Lakh`,
      label: "Money Saved by Customers",
      color: "text-purple-600",
      bgColor: "bg-purple-100",
      description: "Through discounted meals",
      image: "/images/community-impact.jpg",
    },
  ]

  const impactHighlights = [
    {
      icon: Heart,
      title: "Community Feeding",
      value: "15,000+",
      description: "Meals provided to underprivileged communities",
    },
    {
      icon: Award,
      title: "Sustainability Award",
      value: "2024",
      description: "Recognized for environmental impact",
    },
  ]

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Impact on Food Waste</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Together, we're making a real difference in reducing food waste and feeding communities across Punjab
          </p>
          <div className="flex justify-center">
            <img
              src="/images/community-impact.jpg"
              alt="Community Impact"
              className="w-full max-w-md rounded-2xl shadow-lg"
            />
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {statsData.map((stat, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow text-center group">
              <CardContent className="p-8">
                <div className="relative mb-6">
                  <img
                    src={stat.image || "/placeholder.svg"}
                    alt={stat.label}
                    className="w-full h-32 object-cover rounded-lg mb-4 group-hover:scale-105 transition-transform"
                  />
                  <div
                    className={`${stat.bgColor} w-16 h-16 rounded-full flex items-center justify-center mx-auto absolute -bottom-2 left-1/2 transform -translate-x-1/2 border-4 border-white`}
                  >
                    <stat.icon className={`h-8 w-8 ${stat.color}`} />
                  </div>
                </div>
                <div className="space-y-2">
                  <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
                  <p className="text-gray-900 font-medium">{stat.label}</p>
                  <p className="text-gray-600 text-sm">{stat.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Impact Highlights */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {impactHighlights.map((highlight, index) => (
            <Card key={index} className="border-0 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <highlight.icon className="h-8 w-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{highlight.title}</h3>
                <p className="text-3xl font-bold text-orange-600 mb-2">{highlight.value}</p>
                <p className="text-gray-600">{highlight.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Enhanced Call to Action with Both Buttons */}
        <div className="relative overflow-hidden bg-gradient-to-br from-yellow-400 via-orange-500 to-orange-600 rounded-2xl p-12 text-white">
          {/* Background pattern */}
          <div
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23ffffff' fillOpacity='0.3'%3E%3Ccircle cx='30' cy='30' r='4'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            }}
          ></div>

          {/* Floating elements */}
          <div className="absolute top-4 right-4 w-16 h-16 bg-white/10 rounded-full animate-pulse"></div>
          <div className="absolute bottom-4 left-4 w-12 h-12 bg-white/10 rounded-full animate-pulse delay-1000"></div>

          <div className="relative z-10 text-center">
            <h3 className="text-3xl font-bold mb-4 drop-shadow-lg">Join Our Mission</h3>
            <p className="text-xl text-yellow-100 mb-8 max-w-2xl mx-auto drop-shadow-md">
              Be part of the solution. Every order helps reduce food waste and supports local communities.
            </p>

            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              {/* Customer CTA */}
              <div className="text-center">
                <p className="text-yellow-100 text-sm mb-2 font-medium">For Customers</p>
                <Button
                  size="lg"
                  className="bg-white text-orange-600 hover:bg-yellow-50 font-semibold shadow-xl px-8 py-6 text-lg"
                  asChild
                >
                  <Link href="/browse">Start Ordering</Link>
                </Button>
              </div>

              {/* Divider */}
              <div className="hidden sm:block w-px h-16 bg-white/30"></div>
              <div className="sm:hidden w-16 h-px bg-white/30"></div>

              {/* Hotel Partner CTA */}
              <div className="text-center">
                <p className="text-yellow-100 text-sm mb-2 font-medium">For Hotels</p>
                <Button
                  size="lg"
                  className="bg-orange-700 hover:bg-orange-800 text-white font-semibold shadow-xl border-2 border-white/30 px-8 py-6 text-lg"
                  asChild
                >
                  <Link href="/hotel-signup">Partner With Us</Link>
                </Button>
              </div>
            </div>

            {/* Additional info */}
            <div className="mt-8 flex flex-col sm:flex-row gap-6 justify-center items-center text-sm text-yellow-100">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span>Free to join</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                <span>24/7 support</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                <span>Instant approval</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
