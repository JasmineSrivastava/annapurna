"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, ShoppingCart, User, Utensils, Plus } from "lucide-react"
import { useCartStore } from "@/lib/cart-store"

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false)
  const cartItems = useCartStore((state) => state.getTotalItems())

  return (
    <nav className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Utensils className="h-8 w-8 text-orange-600" />
            <span className="text-2xl font-bold text-orange-600">ANNAPURNA</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/browse" className="text-gray-700 hover:text-orange-600 transition-colors font-medium">
              Browse Food
            </Link>
            <Link href="/punjab-hotels" className="text-gray-700 hover:text-orange-600 transition-colors font-medium">
              Punjab Hotels
            </Link>
            <Link href="/how-it-works" className="text-gray-700 hover:text-orange-600 transition-colors">
              How It Works
            </Link>
            <Link href="/impact" className="text-gray-700 hover:text-orange-600 transition-colors">
              Our Impact
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild className="relative">
              <Link href="/cart">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Cart
                {cartItems > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-orange-600">
                    {cartItems}
                  </Badge>
                )}
              </Link>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/login">
                <User className="h-4 w-4 mr-2" />
                Login
              </Link>
            </Button>
            <Button size="sm" asChild className="bg-orange-600 hover:bg-orange-700">
              <Link href="/hotel-signup">
                <Plus className="h-4 w-4 mr-2" />
                Join as Hotel
              </Link>
            </Button>
          </div>

          {/* Mobile Navigation */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="sm">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="flex flex-col space-y-4 mt-8">
                <Link href="/browse" onClick={() => setIsOpen(false)} className="text-lg font-medium">
                  Browse Food
                </Link>
                <Link href="/punjab-hotels" onClick={() => setIsOpen(false)} className="text-lg font-medium">
                  Punjab Hotels
                </Link>
                <Link href="/how-it-works" onClick={() => setIsOpen(false)}>
                  How It Works
                </Link>
                <Link href="/impact" onClick={() => setIsOpen(false)}>
                  Our Impact
                </Link>
                <Link href="/cart" onClick={() => setIsOpen(false)} className="flex items-center">
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Cart ({cartItems})
                </Link>
                <Link href="/login" onClick={() => setIsOpen(false)}>
                  Login
                </Link>
                <Button asChild className="mt-4">
                  <Link href="/hotel-signup" onClick={() => setIsOpen(false)}>
                    Join as Hotel
                  </Link>
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  )
}
