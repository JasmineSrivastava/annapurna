import Link from "next/link"
import { Utensils, Facebook, Twitter, Instagram, Mail, Phone, MapPin, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      {/* Newsletter Section */}
      <div className="border-b border-gray-800">
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-2xl mx-auto text-center">
            <h3 className="text-2xl font-bold mb-4">Stay Updated on Fresh Deals</h3>
            <p className="text-gray-400 mb-6">
              Get notified about new food listings and special offers from hotels near you
            </p>
            <div className="flex gap-4 max-w-md mx-auto">
              <Input
                placeholder="Enter your email"
                className="bg-gray-800 border-gray-700 text-white placeholder-gray-400"
              />
              <Button className="bg-orange-600 hover:bg-orange-700">Subscribe</Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="space-y-6">
            <div className="flex items-center space-x-2">
              <Utensils className="h-8 w-8 text-orange-600" />
              <span className="text-2xl font-bold">ANNAPURNA</span>
            </div>
            <p className="text-gray-400 leading-relaxed">
              Connecting hotels and customers to reduce food waste while providing affordable, quality meals. Join our
              mission for a sustainable future.
            </p>
            <div className="flex space-x-4">
              <div className="bg-gray-800 p-2 rounded-full hover:bg-orange-600 transition-colors cursor-pointer">
                <Facebook className="h-5 w-5" />
              </div>
              <div className="bg-gray-800 p-2 rounded-full hover:bg-orange-600 transition-colors cursor-pointer">
                <Twitter className="h-5 w-5" />
              </div>
              <div className="bg-gray-800 p-2 rounded-full hover:bg-orange-600 transition-colors cursor-pointer">
                <Instagram className="h-5 w-5" />
              </div>
              <div className="bg-gray-800 p-2 rounded-full hover:bg-orange-600 transition-colors cursor-pointer">
                <Mail className="h-5 w-5" />
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-6">For Customers</h3>
            <ul className="space-y-3 text-gray-400">
              <li>
                <Link href="/browse" className="hover:text-orange-600 transition-colors">
                  Browse Food
                </Link>
              </li>
              <li>
                <Link href="/how-it-works" className="hover:text-orange-600 transition-colors">
                  How It Works
                </Link>
              </li>
              <li>
                <Link href="/signup" className="hover:text-orange-600 transition-colors">
                  Sign Up
                </Link>
              </li>
              <li>
                <Link href="/mobile-app" className="hover:text-orange-600 transition-colors">
                  Mobile App
                </Link>
              </li>
              <li>
                <Link href="/support" className="hover:text-orange-600 transition-colors">
                  Customer Support
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-6">For Hotels</h3>
            <ul className="space-y-3 text-gray-400 mb-6">
              <li>
                <Link href="/hotel-signup" className="hover:text-orange-600 transition-colors">
                  Join as Partner
                </Link>
              </li>
              <li>
                <Link href="/hotel-dashboard" className="hover:text-orange-600 transition-colors">
                  Hotel Dashboard
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="hover:text-orange-600 transition-colors">
                  Pricing Plans
                </Link>
              </li>
              <li>
                <Link href="/resources" className="hover:text-orange-600 transition-colors">
                  Resources
                </Link>
              </li>
              <li>
                <Link href="/success-stories" className="hover:text-orange-600 transition-colors">
                  Success Stories
                </Link>
              </li>
            </ul>

            {/* Prominent Partner Button */}
            <Button asChild className="w-full bg-orange-600 hover:bg-orange-700 font-semibold">
              <Link href="/hotel-signup">
                <Users className="h-4 w-4 mr-2" />
                Become a Partner
              </Link>
            </Button>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-6">Contact Info</h3>
            <div className="space-y-4 text-gray-400">
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-orange-600" />
                <span>+91 98765 43210</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-orange-600" />
                <span>hello@annapurna.com</span>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-orange-600 mt-1" />
                <span>123 Food Street, Green City, India 110001</span>
              </div>
            </div>

            <div className="mt-6">
              <h4 className="font-semibold mb-3">Company</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>
                  <Link href="/about" className="hover:text-orange-600 transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="hover:text-orange-600 transition-colors">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-orange-600 transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-orange-600 transition-colors">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            &copy; 2024 ANNAPURNA. All rights reserved. Made with ❤️ for a sustainable future.
          </p>
          <div className="flex items-center gap-4 mt-4 md:mt-0 text-sm text-gray-400">
            <span>Available in 50+ cities</span>
            <span>•</span>
            <span>24/7 Support</span>
            <span>•</span>
            <span>Zero Waste Mission</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
