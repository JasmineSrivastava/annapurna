"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/lib/supabase"
import Link from "next/link"
import { User, Building, Mail, Lock, Phone, MapPin } from "lucide-react"

export default function SignupForm() {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleCustomerSignup = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)

    const formData = new FormData(e.currentTarget)
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    const name = formData.get("name") as string
    const phone = formData.get("phone") as string

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
            phone,
            user_type: "customer",
          },
        },
      })

      if (error) throw error

      toast({
        title: "Account Created!",
        description: "Please check your email to verify your account.",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleHotelSignup = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)

    const formData = new FormData(e.currentTarget)
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    const hotelName = formData.get("hotelName") as string
    const contactPerson = formData.get("contactPerson") as string
    const phone = formData.get("phone") as string
    const address = formData.get("address") as string

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            hotel_name: hotelName,
            contact_person: contactPerson,
            phone,
            address,
            user_type: "hotel",
          },
        },
      })

      if (error) throw error

      toast({
        title: "Hotel Application Submitted!",
        description: "We'll review your application and get back to you within 24 hours.",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">Join ANNAPURNA</CardTitle>
        <p className="text-gray-600">Create your account to start saving food and money</p>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="customer" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="customer" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Customer
            </TabsTrigger>
            <TabsTrigger value="hotel" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              Hotel Partner
            </TabsTrigger>
          </TabsList>

          <TabsContent value="customer">
            <form onSubmit={handleCustomerSignup} className="space-y-4">
              <div>
                <Label htmlFor="customer-name">Full Name</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="customer-name" name="name" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="customer-email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="customer-email" name="email" type="email" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="customer-phone">Phone Number</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="customer-phone" name="phone" type="tel" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="customer-password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="customer-password" name="password" type="password" className="pl-10" required />
                </div>
              </div>
              <Button type="submit" className="w-full bg-orange-600 hover:bg-orange-700" disabled={isLoading}>
                {isLoading ? "Creating Account..." : "Create Customer Account"}
              </Button>
              <p className="text-center text-sm text-gray-600">
                Already have an account?{" "}
                <Link href="/login" className="text-orange-600 hover:underline">
                  Sign in
                </Link>
              </p>
            </form>
          </TabsContent>

          <TabsContent value="hotel">
            <form onSubmit={handleHotelSignup} className="space-y-4">
              <div>
                <Label htmlFor="hotel-name">Hotel Name</Label>
                <div className="relative">
                  <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="hotel-name" name="hotelName" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="contact-person">Contact Person</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="contact-person" name="contactPerson" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="hotel-email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="hotel-email" name="email" type="email" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="hotel-phone">Phone Number</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="hotel-phone" name="phone" type="tel" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="hotel-address">Hotel Address</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="hotel-address" name="address" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="hotel-password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="hotel-password" name="password" type="password" className="pl-10" required />
                </div>
              </div>
              <Button type="submit" className="w-full bg-orange-600 hover:bg-orange-700" disabled={isLoading}>
                {isLoading ? "Submitting Application..." : "Apply as Hotel Partner"}
              </Button>
              <p className="text-center text-sm text-gray-600">
                Already a partner?{" "}
                <Link href="/login" className="text-orange-600 hover:underline">
                  Sign in
                </Link>
              </p>
            </form>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
