"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight, Leaf, Heart } from "lucide-react"
import HeroFoodCarousel from "./hero-food-carousel"

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background with Yellow and Orange Mix */}
      <div className="absolute inset-0 bg-gradient-to-br from-yellow-400 via-orange-400 to-orange-600">
        {/* Subtle pattern overlay */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23ffffff' fillOpacity='0.3'%3E%3Ccircle cx='30' cy='30' r='4'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        ></div>
        {/* Light overlay for better text readability */}
        <div className="absolute inset-0 bg-white/10"></div>
      </div>

      {/* Floating food elements */}
      <div className="absolute top-20 left-10 opacity-30 animate-float">
        <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-2xl border border-white/30">
          🍛
        </div>
      </div>
      <div className="absolute top-40 right-20 opacity-30 animate-float-delayed">
        <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-xl border border-white/30">
          🥘
        </div>
      </div>
      <div className="absolute bottom-40 left-20 opacity-30 animate-float">
        <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-xl border border-white/30">
          🍜
        </div>
      </div>
      <div className="absolute top-60 right-10 opacity-30 animate-float-delayed">
        <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-lg border border-white/30">
          🍲
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="inline-flex items-center bg-white/30 backdrop-blur-sm text-orange-900 px-4 py-2 rounded-full text-sm font-medium border border-white/40 shadow-lg">
                🌱 Reducing Food Waste • Feeding Communities
              </div>

              <h1 className="text-4xl lg:text-6xl font-bold text-white leading-tight drop-shadow-lg">
                Fresh Food from
                <span className="text-yellow-100"> Hotels</span>
                <br />
                at Amazing Prices
              </h1>

              <p className="text-xl text-orange-100 leading-relaxed max-w-lg drop-shadow-md">
                Get premium quality leftover food from top hotels at 50-70% discount. Help reduce food waste while
                enjoying delicious meals delivered fresh to your door.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                asChild
                className="bg-white text-orange-600 hover:bg-orange-50 text-lg px-8 py-6 shadow-xl font-semibold"
              >
                <Link href="/browse">
                  Order Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button
                size="lg"
                asChild
                className="bg-orange-600 hover:bg-orange-700 text-white text-lg px-8 py-6 shadow-xl font-semibold border-2 border-white/30"
              >
                <Link href="/hotel-signup">List Your Food</Link>
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-4">
              <div className="flex items-center gap-2">
                <div className="bg-green-500/80 backdrop-blur-sm p-2 rounded-full border border-white/30 shadow-lg">
                  <Leaf className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white drop-shadow-md">Eco-Friendly</p>
                  <p className="text-xs text-yellow-100">Zero waste mission</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="bg-red-500/80 backdrop-blur-sm p-2 rounded-full border border-white/30 shadow-lg">
                  <Heart className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white drop-shadow-md">Community Impact</p>
                  <p className="text-xs text-yellow-100">Affordable nutrition</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <HeroFoodCarousel />
          </div>
        </div>
      </div>

      {/* Animated background pattern */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent z-10"></div>

      {/* Additional decorative elements */}
      <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-white/5 rounded-full blur-xl"></div>
      <div className="absolute bottom-1/4 right-1/4 w-40 h-40 bg-yellow-300/10 rounded-full blur-xl"></div>

      {/* Custom CSS for animations */}
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(5deg); }
        }
        
        @keyframes float-delayed {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(-5deg); }
        }
        
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        
        .animate-float-delayed {
          animation: float-delayed 8s ease-in-out infinite 2s;
        }
      `}</style>
    </section>
  )
}
