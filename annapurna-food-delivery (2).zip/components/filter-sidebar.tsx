"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"

export default function FilterSidebar() {
  const [priceRange, setPriceRange] = useState([0, 1000])
  const [selectedCuisines, setSelectedCuisines] = useState<string[]>([])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])

  const cuisines = ["Indian", "Chinese", "Italian", "Continental", "Mediterranean", "Thai", "Mexican"]
  const categories = ["Breakfast", "Lunch", "Dinner", "Buffet", "Snacks", "Desserts"]

  const toggleCuisine = (cuisine: string) => {
    setSelectedCuisines((prev) => (prev.includes(cuisine) ? prev.filter((c) => c !== cuisine) : [...prev, cuisine]))
  }

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filters</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Price Range */}
          <div>
            <h3 className="font-medium mb-3">Price Range</h3>
            <Slider value={priceRange} onValueChange={setPriceRange} max={1500} step={50} className="mb-2" />
            <div className="flex justify-between text-sm text-gray-600">
              <span>₹{priceRange[0]}</span>
              <span>₹{priceRange[1]}</span>
            </div>
          </div>

          {/* Cuisine Type */}
          <div>
            <h3 className="font-medium mb-3">Cuisine Type</h3>
            <div className="space-y-2">
              {cuisines.map((cuisine) => (
                <div key={cuisine} className="flex items-center space-x-2">
                  <Checkbox
                    id={cuisine}
                    checked={selectedCuisines.includes(cuisine)}
                    onCheckedChange={() => toggleCuisine(cuisine)}
                  />
                  <label htmlFor={cuisine} className="text-sm">
                    {cuisine}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Category */}
          <div>
            <h3 className="font-medium mb-3">Category</h3>
            <div className="space-y-2">
              {categories.map((category) => (
                <div key={category} className="flex items-center space-x-2">
                  <Checkbox
                    id={category}
                    checked={selectedCategories.includes(category)}
                    onCheckedChange={() => toggleCategory(category)}
                  />
                  <label htmlFor={category} className="text-sm">
                    {category}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <Button
            variant="outline"
            className="w-full"
            onClick={() => {
              setPriceRange([0, 1000])
              setSelectedCuisines([])
              setSelectedCategories([])
            }}
          >
            Clear All Filters
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
