"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Clock, Star, ChevronLeft, ChevronRight } from "lucide-react"
import Link from "next/link"

const heroSpecials = [
  {
    id: 1,
    name: "Royal Punjabi Thali",
    hotel: "The Oberoi Sukhvilas Resort",
    image: "/images/punjabi-thali.jpg",
    originalPrice: 1800,
    discountedPrice: 720,
    timeLeft: "3 hrs",
    rating: 4.9,
    items: ["Dal Makhani", "Butter Chicken", "Fresh Naan", "Basmati Rice", "Raita & Pickle", "Gulab Jamun"],
  },
  {
    id: 2,
    name: "Butter Chicken & Naan",
    hotel: "Country Inn & Suites Amritsar",
    image: "/images/butter-chicken.jpg",
    originalPrice: 900,
    discountedPrice: 315,
    timeLeft: "2.5 hrs",
    rating: 4.7,
    items: ["Creamy Butter Chicken", "Fresh Naan Bread", "Basmati Rice", "Mint Chutney"],
  },
  {
    id: 3,
    name: "Continental Breakfast",
    hotel: "JW Marriott Chandigarh",
    image: "/images/continental-breakfast.jpg",
    originalPrice: 1200,
    discountedPrice: 420,
    timeLeft: "1 hr",
    rating: 4.8,
    items: ["Fresh Croissants", "Eggs Benedict", "Seasonal Fruits", "Premium Coffee", "Fresh Juice"],
  },
]

export default function HeroFoodCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % heroSpecials.length)
    }, 4000)

    return () => clearInterval(timer)
  }, [])

  const currentSpecial = heroSpecials[currentIndex]
  const discount = Math.round(
    ((currentSpecial.originalPrice - currentSpecial.discountedPrice) / currentSpecial.originalPrice) * 100,
  )

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % heroSpecials.length)
  }

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + heroSpecials.length) % heroSpecials.length)
  }

  return (
    <div className="relative">
      <div className="bg-white rounded-3xl shadow-2xl p-6 transform rotate-2 hover:rotate-0 transition-transform duration-300">
        <div className="bg-gradient-to-br from-orange-400 to-red-500 rounded-2xl p-1 relative">
          <img
            src={currentSpecial.image || "/placeholder.svg"}
            alt={currentSpecial.name}
            className="w-full h-80 object-cover rounded-xl transition-opacity duration-500"
          />

          {/* Navigation arrows */}
          <button
            onClick={prevSlide}
            className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-2 transition-colors"
          >
            <ChevronLeft className="h-4 w-4 text-gray-700" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-2 transition-colors"
          >
            <ChevronRight className="h-4 w-4 text-gray-700" />
          </button>
        </div>

        <div className="mt-6 space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-bold text-lg text-gray-900">Today's Special</h3>
              <p className="text-gray-600 text-sm">{currentSpecial.name}</p>
              <p className="text-gray-500 text-xs">{currentSpecial.hotel}</p>
              <div className="flex items-center gap-1 mt-1">
                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                <span className="text-xs text-gray-600">{currentSpecial.rating}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-bold">
                {discount}% OFF
              </div>
              <div className="flex items-center gap-1 mt-1">
                <Clock className="h-3 w-3 text-orange-600" />
                <span className="text-xs text-orange-600 font-medium">{currentSpecial.timeLeft} left</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-xs text-gray-600 mb-2">Includes:</p>
            <div className="grid grid-cols-2 gap-1 text-xs text-gray-700">
              {currentSpecial.items.map((item, index) => (
                <span key={index}>• {item}</span>
              ))}
            </div>
          </div>

          <div className="flex justify-between items-center pt-2 border-t">
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold text-green-600">₹{currentSpecial.discountedPrice}</span>
              <span className="text-sm text-gray-500 line-through">₹{currentSpecial.originalPrice}</span>
            </div>
            <Button size="sm" className="bg-orange-600 hover:bg-orange-700" asChild>
              <Link href="/browse">Order Now</Link>
            </Button>
          </div>
        </div>

        {/* Slide indicators */}
        <div className="flex justify-center gap-1 mt-4">
          {heroSpecials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-2 h-2 rounded-full transition-colors ${
                index === currentIndex ? "bg-orange-600" : "bg-gray-300"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Floating elements */}
      <div className="absolute -top-4 -right-4 bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full text-sm font-bold animate-bounce">
        Fresh!
      </div>
      <div className="absolute -bottom-4 -left-4 bg-green-400 text-green-900 px-3 py-1 rounded-full text-sm font-bold">
        Eco-Friendly
      </div>

      {/* Additional floating badges */}
      <div className="absolute top-1/2 -left-6 bg-orange-500 text-white px-2 py-1 rounded-full text-xs font-bold transform -rotate-12">
        Authentic
      </div>
      <div className="absolute bottom-1/4 -right-6 bg-purple-500 text-white px-2 py-1 rounded-full text-xs font-bold transform rotate-12">
        Premium
      </div>
    </div>
  )
}
