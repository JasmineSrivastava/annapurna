"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, MapPin, Star, Plus } from "lucide-react"

const foodItems = [
  {
    id: 1,
    name: "Gourmet Buffet Selection",
    hotel: "Grand Palace Hotel",
    originalPrice: 1200,
    discountedPrice: 480,
    discount: 60,
    rating: 4.8,
    distance: "2.3 km",
    timeLeft: "2 hours",
    image: "/placeholder.svg?height=200&width=300",
    category: "Buffet",
    cuisine: "Multi-cuisine",
  },
  {
    id: 2,
    name: "Fresh Pasta & Salads",
    hotel: "Italiano Restaurant",
    originalPrice: 800,
    discountedPrice: 320,
    discount: 60,
    rating: 4.6,
    distance: "1.8 km",
    timeLeft: "1.5 hours",
    image: "/placeholder.svg?height=200&width=300",
    category: "Italian",
    cuisine: "Italian",
  },
  {
    id: 3,
    name: "Indian Thali Combo",
    hotel: "Spice Garden",
    originalPrice: 600,
    discountedPrice: 210,
    discount: 65,
    rating: 4.7,
    distance: "3.1 km",
    timeLeft: "3 hours",
    image: "/placeholder.svg?height=200&width=300",
    category: "Indian",
    cuisine: "Indian",
  },
  {
    id: 4,
    name: "Continental Breakfast",
    hotel: "Sunrise Hotel",
    originalPrice: 500,
    discountedPrice: 200,
    discount: 60,
    rating: 4.5,
    distance: "1.2 km",
    timeLeft: "45 minutes",
    image: "/placeholder.svg?height=200&width=300",
    category: "Breakfast",
    cuisine: "Continental",
  },
  {
    id: 5,
    name: "Chinese Dim Sum Platter",
    hotel: "Dragon Palace",
    originalPrice: 900,
    discountedPrice: 315,
    discount: 65,
    rating: 4.9,
    distance: "2.7 km",
    timeLeft: "2.5 hours",
    image: "/placeholder.svg?height=200&width=300",
    category: "Chinese",
    cuisine: "Chinese",
  },
  {
    id: 6,
    name: "Mediterranean Mezze",
    hotel: "Olive Garden Hotel",
    originalPrice: 750,
    discountedPrice: 262,
    discount: 65,
    rating: 4.4,
    distance: "4.2 km",
    timeLeft: "4 hours",
    image: "/placeholder.svg?height=200&width=300",
    category: "Mediterranean",
    cuisine: "Mediterranean",
  },
]

export default function FoodGrid() {
  const [cart, setCart] = useState<number[]>([])

  const addToCart = (itemId: number) => {
    setCart((prev) => [...prev, itemId])
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <p className="text-gray-600">{foodItems.length} items available</p>
        <select className="border rounded-lg px-3 py-2">
          <option>Sort by: Distance</option>
          <option>Sort by: Price</option>
          <option>Sort by: Rating</option>
          <option>Sort by: Time Left</option>
        </select>
      </div>

      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
        {foodItems.map((item) => (
          <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative">
              <img src={item.image || "/placeholder.svg"} alt={item.name} className="w-full h-48 object-cover" />
              <Badge className="absolute top-3 left-3 bg-green-600">{item.discount}% OFF</Badge>
              <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-full text-sm font-medium text-red-600">
                {item.timeLeft} left
              </div>
            </div>

            <CardContent className="p-4">
              <div className="space-y-3">
                <div>
                  <h3 className="font-semibold text-lg">{item.name}</h3>
                  <p className="text-gray-600 text-sm">{item.hotel}</p>
                </div>

                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span>{item.rating}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span>{item.distance}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{item.timeLeft}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xl font-bold text-green-600">₹{item.discountedPrice}</span>
                      <span className="text-sm text-gray-500 line-through">₹{item.originalPrice}</span>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {item.cuisine}
                    </Badge>
                  </div>

                  <Button size="sm" onClick={() => addToCart(item.id)} disabled={cart.includes(item.id)}>
                    <Plus className="h-4 w-4 mr-1" />
                    {cart.includes(item.id) ? "Added" : "Add"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
