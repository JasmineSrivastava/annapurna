"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Edit, Trash2, Eye } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function HotelDashboard() {
  const [isAddingItem, setIsAddingItem] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    toast({
      title: "Food Item Added!",
      description: "Your food item has been listed successfully.",
    })

    setIsLoading(false)
    setIsAddingItem(false)
  }

  const mockFoodItems = [
    {
      id: 1,
      name: "Gourmet Buffet Selection",
      originalPrice: 1200,
      discountedPrice: 480,
      quantity: 5,
      status: "active",
      timeLeft: "2 hours",
    },
    {
      id: 2,
      name: "Continental Breakfast",
      originalPrice: 500,
      discountedPrice: 200,
      quantity: 3,
      status: "active",
      timeLeft: "45 minutes",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Hotel Dashboard</h1>
        <p className="text-gray-600">Manage your food listings and track sales</p>
      </div>

      <Tabs defaultValue="listings" className="space-y-6">
        <TabsList>
          <TabsTrigger value="listings">Food Listings</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="profile">Profile</TabsTrigger>
        </TabsList>

        <TabsContent value="listings" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Your Food Listings</h2>
            <Button onClick={() => setIsAddingItem(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add New Item
            </Button>
          </div>

          {isAddingItem && (
            <Card>
              <CardHeader>
                <CardTitle>Add New Food Item</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddItem} className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="itemName">Item Name *</Label>
                      <Input id="itemName" required />
                    </div>
                    <div>
                      <Label htmlFor="category">Category *</Label>
                      <select id="category" className="w-full border rounded-lg px-3 py-2" required>
                        <option value="">Select Category</option>
                        <option value="breakfast">Breakfast</option>
                        <option value="lunch">Lunch</option>
                        <option value="dinner">Dinner</option>
                        <option value="buffet">Buffet</option>
                        <option value="snacks">Snacks</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="originalPrice">Original Price (₹) *</Label>
                      <Input id="originalPrice" type="number" required />
                    </div>
                    <div>
                      <Label htmlFor="discountedPrice">Discounted Price (₹) *</Label>
                      <Input id="discountedPrice" type="number" required />
                    </div>
                    <div>
                      <Label htmlFor="quantity">Quantity Available *</Label>
                      <Input id="quantity" type="number" required />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea id="description" />
                  </div>

                  <div>
                    <Label htmlFor="image">Food Image</Label>
                    <Input id="image" type="file" accept="image/*" />
                  </div>

                  <div className="flex gap-4">
                    <Button type="submit" disabled={isLoading}>
                      {isLoading ? "Adding..." : "Add Item"}
                    </Button>
                    <Button type="button" variant="outline" onClick={() => setIsAddingItem(false)}>
                      Cancel
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}

          <div className="grid gap-4">
            {mockFoodItems.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <h3 className="font-semibold text-lg">{item.name}</h3>
                      <div className="flex items-center gap-4">
                        <span className="text-green-600 font-medium">₹{item.discountedPrice}</span>
                        <span className="text-gray-500 line-through">₹{item.originalPrice}</span>
                        <Badge variant="secondary">Qty: {item.quantity}</Badge>
                        <Badge variant={item.status === "active" ? "default" : "secondary"}>{item.status}</Badge>
                      </div>
                      <p className="text-sm text-gray-600">Time left: {item.timeLeft}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="orders">
          <Card>
            <CardHeader>
              <CardTitle>Recent Orders</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">No orders yet. Start listing your food items to receive orders!</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Total Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-green-600">₹0</p>
                <p className="text-sm text-gray-600">This month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Items Sold</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold">0</p>
                <p className="text-sm text-gray-600">This month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Food Saved</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold">0 kg</p>
                <p className="text-sm text-gray-600">From waste</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Hotel Profile</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label>Hotel Name</Label>
                  <Input defaultValue="Grand Palace Hotel" />
                </div>
                <div>
                  <Label>Contact Email</Label>
                  <Input defaultValue="contact@grandpalace.com" />
                </div>
                <div>
                  <Label>Phone Number</Label>
                  <Input defaultValue="+91 98765 43210" />
                </div>
                <Button>Update Profile</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
