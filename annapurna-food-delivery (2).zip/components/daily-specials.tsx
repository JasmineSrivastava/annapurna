"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, Star, MapPin, ChefHat, Flame } from "lucide-react"
import Link from "next/link"

const dailySpecials = [
  {
    id: "special_1",
    name: "Amritsari Kulcha Combo",
    hotel: "Hyatt Regency Amritsar",
    image: "/images/amritsari-kulcha.jpg",
    originalPrice: 800,
    discountedPrice: 280,
    timeLeft: "2 hours",
    rating: 4.8,
    description: "Authentic Amritsari kulcha with chole, lassi, and pickle",
    city: "Amritsar",
  },
  {
    id: "special_2",
    name: "Tandoori Mixed Grill",
    hotel: "Radisson Blu Hotel Amritsar",
    image: "/images/tandoori-grill.jpg",
    originalPrice: 1200,
    discountedPrice: 480,
    timeLeft: "1.5 hours",
    rating: 4.7,
    description: "Assorted tandoori items with fresh naan and mint chutney",
    city: "Amritsar",
  },
  {
    id: "special_3",
    name: "International Buffet",
    hotel: "JW Marriott Chandigarh",
    image: "/images/buffet-selection.jpg",
    originalPrice: 2500,
    discountedPrice: 875,
    timeLeft: "4 hours",
    rating: 4.9,
    description: "Premium buffet with global cuisines and live counters",
    city: "Chandigarh",
  },
]

export default function DailySpecials() {
  const [currentSpecial, setCurrentSpecial] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSpecial((prev) => (prev + 1) % dailySpecials.length)
    }, 5000) // Change every 5 seconds

    return () => clearInterval(timer)
  }, [])

  const special = dailySpecials[currentSpecial]
  const discount = Math.round(((special.originalPrice - special.discountedPrice) / special.originalPrice) * 100)

  return (
    <section className="py-16 relative overflow-hidden">
      {/* Yellow-Orange gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-yellow-400 via-orange-500 to-orange-600"></div>

      {/* Subtle pattern overlay */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fillOpacity='0.4'%3E%3Cpath d='M20 20c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10zm10 0c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10z'/%3E%3C/g%3E%3C/svg%3E")`,
        }}
      ></div>

      {/* Animated background elements */}
      <div className="absolute top-10 left-10 w-20 h-20 bg-white/10 rounded-full animate-pulse"></div>
      <div className="absolute top-40 right-20 w-16 h-16 bg-yellow-300/20 rounded-full animate-pulse delay-1000"></div>
      <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-white/10 rounded-full animate-pulse delay-2000"></div>
      <div className="absolute bottom-40 right-1/3 w-24 h-24 bg-orange-300/20 rounded-full animate-pulse delay-500"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-white/30 backdrop-blur px-4 py-2 rounded-full text-sm font-medium mb-4 text-orange-900 border border-white/40 shadow-lg">
            <Flame className="h-4 w-4" />
            Limited Time Offers
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold mb-4 text-white drop-shadow-lg">Today's Special Deals</h2>
          <p className="text-xl text-yellow-100 max-w-2xl mx-auto drop-shadow-md">
            Handpicked premium dishes from top Punjab hotels at unbeatable prices
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="overflow-hidden bg-white/15 backdrop-blur-lg border-white/30 shadow-2xl">
            <CardContent className="p-0">
              <div className="grid lg:grid-cols-2 gap-0">
                <div className="relative">
                  <img
                    src={special.image || "/placeholder.svg"}
                    alt={special.name}
                    className="w-full h-80 lg:h-full object-cover"
                  />
                  <Badge className="absolute top-4 left-4 bg-green-600 text-white shadow-lg">{discount}% OFF</Badge>
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-red-600 font-medium flex items-center gap-1 shadow-lg">
                    <Clock className="h-4 w-4" />
                    {special.timeLeft}
                  </div>
                  <div className="absolute bottom-4 left-4 bg-orange-600 text-white px-3 py-1 rounded-full text-sm font-medium shadow-lg">
                    {special.city}
                  </div>
                </div>

                <div className="p-8 lg:p-12 flex flex-col justify-center text-white">
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <ChefHat className="h-5 w-5 text-yellow-200" />
                        <span className="text-yellow-200 text-sm font-medium">Featured Special</span>
                      </div>
                      <h3 className="text-3xl font-bold text-white mb-2 drop-shadow-md">{special.name}</h3>
                      <p className="text-yellow-100 flex items-center gap-1 mb-3">
                        <MapPin className="h-4 w-4" />
                        {special.hotel}
                      </p>
                      <p className="text-yellow-100 leading-relaxed">{special.description}</p>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1">
                        <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                        <span className="text-white font-medium">{special.rating}</span>
                      </div>
                      <div className="text-yellow-200">•</div>
                      <span className="text-yellow-200">Premium Quality</span>
                      <div className="text-yellow-200">•</div>
                      <span className="text-yellow-200">Fresh Today</span>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center gap-4">
                        <span className="text-4xl font-bold text-white drop-shadow-md">₹{special.discountedPrice}</span>
                        <span className="text-xl text-yellow-200 line-through">₹{special.originalPrice}</span>
                        <Badge className="bg-green-600 text-white shadow-lg">
                          Save ₹{special.originalPrice - special.discountedPrice}
                        </Badge>
                      </div>

                      <Button
                        size="lg"
                        className="bg-white text-orange-600 hover:bg-yellow-50 font-semibold shadow-xl"
                        asChild
                      >
                        <Link href="/browse">Order This Special Now</Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Indicator dots */}
          <div className="flex justify-center gap-2 mt-8">
            {dailySpecials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSpecial(index)}
                className={`w-3 h-3 rounded-full transition-colors shadow-lg ${
                  index === currentSpecial ? "bg-white" : "bg-white/40"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
