"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/lib/supabase"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { User, Building, Mail, Lock } from "lucide-react"

export default function LoginForm() {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>, userType: string) => {
    e.preventDefault()
    setIsLoading(true)

    const formData = new FormData(e.currentTarget)
    const email = formData.get("email") as string
    const password = formData.get("password") as string

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) throw error

      toast({
        title: "Welcome back!",
        description: "You have been successfully logged in.",
      })

      // Redirect based on user type
      if (userType === "hotel") {
        router.push("/hotel-dashboard")
      } else {
        router.push("/browse")
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">Welcome Back to ANNAPURNA</CardTitle>
        <p className="text-gray-600">Sign in to your account</p>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="customer" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="customer" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Customer
            </TabsTrigger>
            <TabsTrigger value="hotel" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              Hotel Partner
            </TabsTrigger>
          </TabsList>

          <TabsContent value="customer">
            <form onSubmit={(e) => handleLogin(e, "customer")} className="space-y-4">
              <div>
                <Label htmlFor="customer-email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="customer-email" name="email" type="email" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="customer-password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="customer-password" name="password" type="password" className="pl-10" required />
                </div>
              </div>
              <Button type="submit" className="w-full bg-orange-600 hover:bg-orange-700" disabled={isLoading}>
                {isLoading ? "Signing in..." : "Sign In"}
              </Button>
              <p className="text-center text-sm text-gray-600">
                Don't have an account?{" "}
                <Link href="/signup" className="text-orange-600 hover:underline">
                  Sign up
                </Link>
              </p>
            </form>
          </TabsContent>

          <TabsContent value="hotel">
            <form onSubmit={(e) => handleLogin(e, "hotel")} className="space-y-4">
              <div>
                <Label htmlFor="hotel-email">Hotel Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="hotel-email" name="email" type="email" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="hotel-password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="hotel-password" name="password" type="password" className="pl-10" required />
                </div>
              </div>
              <Button type="submit" className="w-full bg-orange-600 hover:bg-orange-700" disabled={isLoading}>
                {isLoading ? "Signing in..." : "Sign In to Dashboard"}
              </Button>
              <p className="text-center text-sm text-gray-600">
                New hotel partner?{" "}
                <Link href="/signup" className="text-orange-600 hover:underline">
                  Apply now
                </Link>
              </p>
            </form>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
