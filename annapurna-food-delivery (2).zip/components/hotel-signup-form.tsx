"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/hooks/use-toast"

export default function HotelSignupForm() {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    toast({
      title: "Application Submitted!",
      description: "We'll review your application and get back to you within 24 hours.",
    })

    setIsLoading(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Hotel Registration</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="hotelName">Hotel Name *</Label>
              <Input id="hotelName" required />
            </div>
            <div>
              <Label htmlFor="contactPerson">Contact Person *</Label>
              <Input id="contactPerson" required />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="email">Email Address *</Label>
              <Input id="email" type="email" required />
            </div>
            <div>
              <Label htmlFor="phone">Phone Number *</Label>
              <Input id="phone" type="tel" required />
            </div>
          </div>

          <div>
            <Label htmlFor="address">Hotel Address *</Label>
            <Textarea id="address" required />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="city">City *</Label>
              <Input id="city" required />
            </div>
            <div>
              <Label htmlFor="pincode">Pincode *</Label>
              <Input id="pincode" required />
            </div>
          </div>

          <div>
            <Label htmlFor="cuisineTypes">Cuisine Types Offered</Label>
            <Input id="cuisineTypes" placeholder="e.g., Indian, Chinese, Continental" />
          </div>

          <div>
            <Label htmlFor="avgDailyLeftover">Average Daily Leftover Food (in kg)</Label>
            <Input id="avgDailyLeftover" type="number" />
          </div>

          <div>
            <Label htmlFor="description">Brief Description of Your Hotel</Label>
            <Textarea id="description" />
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox id="terms" required />
            <Label htmlFor="terms" className="text-sm">
              I agree to the Terms of Service and Privacy Policy
            </Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox id="foodSafety" required />
            <Label htmlFor="foodSafety" className="text-sm">
              I confirm that our hotel maintains proper food safety standards
            </Label>
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Submitting..." : "Submit Application"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
