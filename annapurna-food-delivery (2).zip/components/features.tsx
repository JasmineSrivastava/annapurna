import { Card, CardContent } from "@/components/ui/card"
import { Clock, DollarSign, Shield, Truck } from "lucide-react"

const features = [
  {
    icon: DollarSign,
    title: "Save Money",
    description: "Get premium hotel food at 30-70% discount compared to regular prices",
  },
  {
    icon: Clock,
    title: "Fresh & Quick",
    description: "Food is prepared fresh daily and available for immediate pickup or delivery",
  },
  {
    icon: Shield,
    title: "Quality Assured",
    description: "All partner hotels maintain high food safety standards and quality checks",
  },
  {
    icon: Truck,
    title: "Fast Delivery",
    description: "Quick delivery within 30 minutes or convenient pickup options",
  },
]

export default function Features() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Why Choose ANNAPURNA?</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            We make it easy to access quality food while making a positive impact on the environment
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <feature.icon className="h-8 w-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-semibold mb-4">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
