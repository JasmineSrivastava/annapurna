import Navigation from "@/components/navigation"
import Hero from "@/components/hero"
import DailySpecials from "@/components/daily-specials"
import FeaturedFood from "@/components/featured-food"
import Stats from "@/components/stats"
import Footer from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <Hero />
      <DailySpecials />
      <FeaturedFood />
      <Stats />
      <Footer />
    </div>
  )
}
