import Navigation from "@/components/navigation"
import HotelDashboard from "@/components/hotel-dashboard"

export default function HotelDashboardPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <HotelDashboard />
    </div>
  )
}
