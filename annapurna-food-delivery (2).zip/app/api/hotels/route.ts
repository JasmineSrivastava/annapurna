import { type NextRequest, NextResponse } from "next/server"
import { put } from "@vercel/blob"

// In a real app, this would be stored in a database
const hotels: any[] = []

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()

    const hotelData = {
      id: Date.now().toString(),
      hotelName: formData.get("hotelName"),
      contactPerson: formData.get("contactPerson"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      address: formData.get("address"),
      city: formData.get("city"),
      pincode: formData.get("pincode"),
      cuisineTypes: formData.get("cuisineTypes"),
      avgDailyLeftover: formData.get("avgDailyLeftover"),
      description: formData.get("description"),
      status: "pending",
      createdAt: new Date().toISOString(),
    }

    // Store hotel data in blob storage
    const blob = await put(`hotels/${hotelData.id}.json`, JSON.stringify(hotelData), {
      access: "public",
    })

    hotels.push(hotelData)

    return NextResponse.json({
      success: true,
      message: "Hotel application submitted successfully",
      hotelId: hotelData.id,
    })
  } catch (error) {
    return NextResponse.json({ success: false, message: "Failed to submit application" }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({ hotels })
}
