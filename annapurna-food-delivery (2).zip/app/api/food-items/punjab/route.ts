import { NextResponse } from "next/server"

const punjabFoodItems = [
  {
    id: "food_1",
    hotel_id: "hotel_1",
    hotel_name: "The Oberoi Sukhvilas Resort & Spa",
    name: "Royal Punjabi Thali",
    description: "Complete traditional Punjabi meal with dal makhani, butter chicken, naan, rice, and dessert",
    original_price: 1800,
    discounted_price: 720,
    category: "Punjabi",
    cuisine: "North Indian",
    quantity: 8,
    image_url: "/images/punjabi-thali.jpg",
    city: "Chandigarh",
    expiry_time: "3 hours",
    rating: 4.9,
    distance: "2.1 km",
    is_available: true,
    created_at: new Date().toISOString(),
  },
  {
    id: "food_2",
    hotel_id: "hotel_2",
    hotel_name: "Hyatt Regency Amritsar",
    name: "Amritsari Kulcha Combo",
    description: "Authentic Amritsari kulcha with chole, lassi, and pickle - a local specialty",
    original_price: 800,
    discounted_price: 280,
    category: "Punjabi",
    cuisine: "Punjabi",
    quantity: 12,
    image_url: "/images/amritsari-kulcha.jpg",
    city: "Amritsar",
    expiry_time: "2 hours",
    rating: 4.8,
    distance: "1.5 km",
    is_available: true,
    created_at: new Date().toISOString(),
  },
  {
    id: "food_3",
    hotel_id: "hotel_3",
    hotel_name: "Radisson Blu Hotel Amritsar",
    name: "Tandoori Mixed Grill",
    description: "Assorted tandoori items including chicken tikka, seekh kebab, and tandoori roti",
    original_price: 1200,
    discounted_price: 480,
    category: "Tandoori",
    cuisine: "North Indian",
    quantity: 6,
    image_url: "/images/tandoori-grill.jpg",
    city: "Amritsar",
    expiry_time: "2.5 hours",
    rating: 4.7,
    distance: "3.2 km",
    is_available: true,
    created_at: new Date().toISOString(),
  },
  {
    id: "food_4",
    hotel_id: "hotel_4",
    hotel_name: "JW Marriott Hotel Chandigarh",
    name: "International Buffet Selection",
    description: "Premium buffet with Italian pasta, Chinese stir-fry, Indian curries, and continental dishes",
    original_price: 2500,
    discounted_price: 875,
    category: "Buffet",
    cuisine: "Multi-cuisine",
    quantity: 10,
    image_url: "/images/buffet-selection.jpg",
    city: "Chandigarh",
    expiry_time: "4 hours",
    rating: 4.9,
    distance: "1.8 km",
    is_available: true,
    created_at: new Date().toISOString(),
  },
  {
    id: "food_5",
    hotel_id: "hotel_5",
    hotel_name: "Hotel City Heart Premium",
    name: "Makki di Roti & Sarson da Saag",
    description: "Traditional Punjabi winter special with fresh makki roti, sarson da saag, and white butter",
    original_price: 600,
    discounted_price: 210,
    category: "Traditional",
    cuisine: "Punjabi",
    quantity: 15,
    image_url: "/images/makki-sarson.jpg",
    city: "Ludhiana",
    expiry_time: "1.5 hours",
    rating: 4.6,
    distance: "2.7 km",
    is_available: true,
    created_at: new Date().toISOString(),
  },
  {
    id: "food_6",
    hotel_id: "hotel_6",
    hotel_name: "Ramada by Wyndham Jalandhar",
    name: "Chole Bhature Deluxe",
    description: "Fluffy bhature with spicy chole, onions, pickle, and sweet lassi",
    original_price: 500,
    discounted_price: 175,
    category: "Punjabi",
    cuisine: "North Indian",
    quantity: 20,
    image_url: "/images/chole-bhature.jpg",
    city: "Jalandhar",
    expiry_time: "2 hours",
    rating: 4.5,
    distance: "4.1 km",
    is_available: true,
    created_at: new Date().toISOString(),
  },
  {
    id: "food_7",
    hotel_id: "hotel_7",
    hotel_name: "Hotel Sunbeam",
    name: "Rajma Chawal Combo",
    description: "Homestyle rajma with basmati rice, papad, and pickle - comfort food at its best",
    original_price: 450,
    discounted_price: 158,
    category: "Comfort Food",
    cuisine: "North Indian",
    quantity: 18,
    image_url: "/images/rajma-chawal.jpg",
    city: "Chandigarh",
    expiry_time: "3 hours",
    rating: 4.4,
    distance: "1.9 km",
    is_available: true,
    created_at: new Date().toISOString(),
  },
  {
    id: "food_8",
    hotel_id: "hotel_8",
    hotel_name: "Country Inn & Suites Amritsar",
    name: "Butter Chicken & Naan",
    description: "Creamy butter chicken with fresh naan bread and basmati rice",
    original_price: 900,
    discounted_price: 315,
    category: "North Indian",
    cuisine: "North Indian",
    quantity: 14,
    image_url: "/images/butter-chicken.jpg",
    city: "Amritsar",
    expiry_time: "2.5 hours",
    rating: 4.7,
    distance: "2.3 km",
    is_available: true,
    created_at: new Date().toISOString(),
  },
  {
    id: "food_9",
    hotel_id: "hotel_1",
    hotel_name: "The Oberoi Sukhvilas Resort & Spa",
    name: "Continental Breakfast Platter",
    description: "Fresh croissants, eggs benedict, fruits, coffee, and juice",
    original_price: 1200,
    discounted_price: 420,
    category: "Breakfast",
    cuisine: "Continental",
    quantity: 12,
    image_url: "/images/continental-breakfast.jpg",
    city: "Chandigarh",
    expiry_time: "1 hour",
    rating: 4.8,
    distance: "2.1 km",
    is_available: true,
    created_at: new Date().toISOString(),
  },
  {
    id: "food_10",
    hotel_id: "hotel_4",
    hotel_name: "JW Marriott Hotel Chandigarh",
    name: "Sushi & Asian Fusion",
    description: "Fresh sushi rolls, dim sum, and Asian fusion dishes",
    original_price: 1800,
    discounted_price: 630,
    category: "Asian",
    cuisine: "Japanese",
    quantity: 8,
    image_url: "/images/sushi-asian.jpg",
    city: "Chandigarh",
    expiry_time: "2 hours",
    rating: 4.9,
    distance: "1.8 km",
    is_available: true,
    created_at: new Date().toISOString(),
  },
]

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const city = searchParams.get("city")
    const cuisine = searchParams.get("cuisine")
    const category = searchParams.get("category")
    const minPrice = searchParams.get("minPrice")
    const maxPrice = searchParams.get("maxPrice")

    let filteredItems = punjabFoodItems.filter((item) => item.is_available)

    if (city) {
      filteredItems = filteredItems.filter((item) => item.city.toLowerCase().includes(city.toLowerCase()))
    }

    if (cuisine) {
      filteredItems = filteredItems.filter((item) => item.cuisine.toLowerCase().includes(cuisine.toLowerCase()))
    }

    if (category) {
      filteredItems = filteredItems.filter((item) => item.category.toLowerCase().includes(category.toLowerCase()))
    }

    if (minPrice) {
      filteredItems = filteredItems.filter((item) => item.discounted_price >= Number.parseInt(minPrice))
    }

    if (maxPrice) {
      filteredItems = filteredItems.filter((item) => item.discounted_price <= Number.parseInt(maxPrice))
    }

    return NextResponse.json({
      success: true,
      foodItems: filteredItems,
      total: filteredItems.length,
      cities: [...new Set(punjabFoodItems.map((item) => item.city))],
      cuisines: [...new Set(punjabFoodItems.map((item) => item.cuisine))],
    })
  } catch (error) {
    return NextResponse.json({ success: false, message: "Failed to fetch food items" }, { status: 500 })
  }
}
