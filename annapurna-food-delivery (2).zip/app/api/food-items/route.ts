import { type NextRequest, NextResponse } from "next/server"
import { put } from "@vercel/blob"

// Mock data - in a real app, this would come from a database
const foodItems = [
  {
    id: "1",
    name: "Gourmet Buffet Selection",
    hotelId: "hotel1",
    hotelName: "Grand Palace Hotel",
    originalPrice: 1200,
    discountedPrice: 480,
    discount: 60,
    rating: 4.8,
    distance: "2.3 km",
    timeLeft: "2 hours",
    image: "/placeholder.svg?height=200&width=300",
    category: "Buffet",
    cuisine: "Multi-cuisine",
    description: "Fresh buffet items including Indian, Chinese, and Continental dishes",
    quantity: 5,
    available: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: "2",
    name: "Fresh Pasta & Salads",
    hotelId: "hotel2",
    hotelName: "Italiano Restaurant",
    originalPrice: 800,
    discountedPrice: 320,
    discount: 60,
    rating: 4.6,
    distance: "1.8 km",
    timeLeft: "1.5 hours",
    image: "/placeholder.svg?height=200&width=300",
    category: "Italian",
    cuisine: "Italian",
    description: "Authentic Italian pasta with fresh garden salads",
    quantity: 8,
    available: true,
    createdAt: new Date().toISOString(),
  },
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const cuisine = searchParams.get("cuisine")
  const category = searchParams.get("category")
  const minPrice = searchParams.get("minPrice")
  const maxPrice = searchParams.get("maxPrice")

  let filteredItems = foodItems.filter((item) => item.available)

  if (cuisine) {
    filteredItems = filteredItems.filter((item) => item.cuisine.toLowerCase().includes(cuisine.toLowerCase()))
  }

  if (category) {
    filteredItems = filteredItems.filter((item) => item.category.toLowerCase().includes(category.toLowerCase()))
  }

  if (minPrice) {
    filteredItems = filteredItems.filter((item) => item.discountedPrice >= Number.parseInt(minPrice))
  }

  if (maxPrice) {
    filteredItems = filteredItems.filter((item) => item.discountedPrice <= Number.parseInt(maxPrice))
  }

  return NextResponse.json({ foodItems: filteredItems })
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const image = formData.get("image") as File

    let imageUrl = "/placeholder.svg?height=200&width=300"

    if (image) {
      const blob = await put(`food-images/${Date.now()}-${image.name}`, image, {
        access: "public",
      })
      imageUrl = blob.url
    }

    const foodItem = {
      id: Date.now().toString(),
      name: formData.get("name"),
      hotelId: formData.get("hotelId"),
      hotelName: formData.get("hotelName"),
      originalPrice: Number.parseInt(formData.get("originalPrice") as string),
      discountedPrice: Number.parseInt(formData.get("discountedPrice") as string),
      discount: Number.parseInt(formData.get("discount") as string),
      category: formData.get("category"),
      cuisine: formData.get("cuisine"),
      description: formData.get("description"),
      quantity: Number.parseInt(formData.get("quantity") as string),
      image: imageUrl,
      available: true,
      rating: 4.5,
      distance: "2.0 km",
      timeLeft: formData.get("timeLeft"),
      createdAt: new Date().toISOString(),
    }

    // Store in blob storage
    const blob = await put(`food-items/${foodItem.id}.json`, JSON.stringify(foodItem), {
      access: "public",
    })

    return NextResponse.json({
      success: true,
      message: "Food item added successfully",
      foodItem,
    })
  } catch (error) {
    return NextResponse.json({ success: false, message: "Failed to add food item" }, { status: 500 })
  }
}
