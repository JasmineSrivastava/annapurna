import Navigation from "@/components/navigation"
import HowItWorksContent from "@/components/how-it-works-content"
import Footer from "@/components/footer"

export default function HowItWorksPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <HowItWorksContent />
      <Footer />
    </div>
  )
}
