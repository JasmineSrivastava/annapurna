"use client"

import { useState, useEffect } from "react"
import Navigation from "@/components/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, MapPin, Phone, Utensils, Users } from "lucide-react"
import Link from "next/link"

interface Hotel {
  id: string
  name: string
  city: string
  address: string
  rating: number
  cuisine_types: string[]
  phone: string
  image: string
  description: string
  avg_daily_leftover: number
  status: string
}

export default function PunjabHotelsPage() {
  const [hotels, setHotels] = useState<Hotel[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchHotels()
  }, [])

  const fetchHotels = async () => {
    try {
      const response = await fetch("/api/hotels/punjab")
      const data = await response.json()

      if (data.success) {
        setHotels(data.hotels)
      }
      setLoading(false)
    } catch (error) {
      console.error("Error fetching hotels:", error)
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Partner Hotels in Punjab</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover premium hotels across Punjab offering fresh, quality food at discounted prices
          </p>
        </div>

        {/* Hotels Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <div className="animate-pulse">
                  <div className="h-48 bg-gray-200"></div>
                  <div className="p-6 space-y-4">
                    <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                    <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {hotels.map((hotel) => (
              <Card key={hotel.id} className="overflow-hidden hover:shadow-xl transition-all duration-300 group">
                <div className="relative">
                  <img
                    src={hotel.image || "/placeholder.svg"}
                    alt={hotel.name}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <Badge className="absolute top-3 left-3 bg-orange-600">{hotel.city}</Badge>
                  <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-full flex items-center gap-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{hotel.rating}</span>
                  </div>
                </div>

                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-bold text-xl text-gray-900 group-hover:text-orange-600 transition-colors">
                        {hotel.name}
                      </h3>
                      <p className="text-gray-600 text-sm flex items-center gap-1 mt-1">
                        <MapPin className="h-3 w-3" />
                        {hotel.address}
                      </p>
                      <p className="text-gray-500 text-sm mt-2">{hotel.description}</p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Phone className="h-4 w-4" />
                        <span>{hotel.phone}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Utensils className="h-4 w-4" />
                        <span>{hotel.avg_daily_leftover}kg daily leftover</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <p className="text-sm font-medium text-gray-700">Cuisine Types:</p>
                      <div className="flex flex-wrap gap-1">
                        {hotel.cuisine_types.map((cuisine, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {cuisine}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <Button asChild className="w-full bg-orange-600 hover:bg-orange-700">
                        <Link href={`/browse?hotel=${hotel.id}`}>View Available Food</Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Call to Action */}
        <div className="mt-16 text-center bg-orange-50 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Want to Join Our Network?</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Partner with ANNAPURNA to reduce food waste and generate additional revenue from your hotel's leftover food
          </p>
          <Button size="lg" asChild className="bg-orange-600 hover:bg-orange-700">
            <Link href="/hotel-signup">
              <Users className="h-5 w-5 mr-2" />
              Become a Partner Hotel
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
