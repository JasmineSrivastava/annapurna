import Navigation from "@/components/navigation"
import ImpactContent from "@/components/impact-content"
import Footer from "@/components/footer"

export default function ImpactPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <ImpactContent />
      <Footer />
    </div>
  )
}
