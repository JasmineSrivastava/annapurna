"use client"

import { useState, useEffect } from "react"
import Navigation from "@/components/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Clock, MapPin, Star, Plus, Search, ChefHat, Check } from "lucide-react"
import { useCartStore } from "@/lib/cart-store"
import { useToast } from "@/hooks/use-toast"

interface FoodItem {
  id: string
  name: string
  hotel_name: string
  original_price: number
  discounted_price: number
  image_url: string
  category: string
  cuisine: string
  city: string
  expiry_time: string
  rating: number
  distance: string
  description: string
}

export default function BrowsePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCity, setSelectedCity] = useState("")
  const [selectedCuisine, setSelectedCuisine] = useState("")
  const [foodItems, setFoodItems] = useState<FoodItem[]>([])
  const [cities, setCities] = useState<string[]>([])
  const [cuisines, setCuisines] = useState<string[]>([])
  const [loading, setLoading] = useState(true)

  const [addedItems, setAddedItems] = useState<Set<string>>(new Set())
  const addItem = useCartStore((state) => state.addItem)
  const { toast } = useToast()

  const handleAddToCart = (item: FoodItem) => {
    addItem({
      id: item.id,
      name: item.name,
      hotel_name: item.hotel_name,
      price: item.discounted_price,
      original_price: item.original_price,
      image_url: item.image_url,
    })

    setAddedItems((prev) => new Set(prev).add(item.id))

    toast({
      title: "Added to Cart!",
      description: `${item.name} has been added to your cart.`,
    })

    setTimeout(() => {
      setAddedItems((prev) => {
        const newSet = new Set(prev)
        newSet.delete(item.id)
        return newSet
      })
    }, 2000)
  }

  useEffect(() => {
    fetchFoodItems()
  }, [selectedCity, selectedCuisine])

  const fetchFoodItems = async () => {
    try {
      const params = new URLSearchParams()
      if (selectedCity) params.append("city", selectedCity)
      if (selectedCuisine) params.append("cuisine", selectedCuisine)

      const response = await fetch(`/api/food-items/punjab?${params}`)
      const data = await response.json()

      if (data.success) {
        setFoodItems(data.foodItems)
        setCities(data.cities)
        setCuisines(data.cuisines)
      }
      setLoading(false)
    } catch (error) {
      console.error("Error fetching food items:", error)
      setLoading(false)
    }
  }

  const calculateDiscount = (original: number, discounted: number) => {
    return Math.round(((original - discounted) / original) * 100)
  }

  const filteredItems = foodItems.filter(
    (item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.hotel_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <ChefHat className="h-8 w-8 text-orange-600" />
            <h1 className="text-3xl font-bold text-gray-900">Punjab Hotels Food</h1>
          </div>
          <p className="text-gray-600">
            Authentic Punjabi cuisine and international dishes from top hotels across Punjab
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                placeholder="Search for food, hotels, or dishes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="border rounded-lg px-3 py-2 bg-white min-w-[150px]"
            >
              <option value="">All Cities</option>
              {cities.map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
            <select
              value={selectedCuisine}
              onChange={(e) => setSelectedCuisine(e.target.value)}
              className="border rounded-lg px-3 py-2 bg-white min-w-[150px]"
            >
              <option value="">All Cuisines</option>
              {cuisines.map((cuisine) => (
                <option key={cuisine} value={cuisine}>
                  {cuisine}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Filters */}
          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedCuisine === "Punjabi" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCuisine(selectedCuisine === "Punjabi" ? "" : "Punjabi")}
            >
              Punjabi
            </Button>
            <Button
              variant={selectedCuisine === "North Indian" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCuisine(selectedCuisine === "North Indian" ? "" : "North Indian")}
            >
              North Indian
            </Button>
            <Button
              variant={selectedCity === "Amritsar" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCity(selectedCity === "Amritsar" ? "" : "Amritsar")}
            >
              Amritsar
            </Button>
            <Button
              variant={selectedCity === "Chandigarh" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCity(selectedCity === "Chandigarh" ? "" : "Chandigarh")}
            >
              Chandigarh
            </Button>
          </div>
        </div>

        {/* Results */}
        <div className="mb-6 flex justify-between items-center">
          <p className="text-gray-600">
            {loading ? "Loading..." : `${filteredItems.length} items available in Punjab`}
          </p>
          <select className="border rounded-lg px-3 py-2 bg-white">
            <option>Sort by: Distance</option>
            <option>Sort by: Price (Low to High)</option>
            <option>Sort by: Price (High to Low)</option>
            <option>Sort by: Rating</option>
            <option>Sort by: Time Left</option>
          </select>
        </div>

        {/* Food Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <div className="animate-pulse">
                  <div className="h-48 bg-gray-200"></div>
                  <div className="p-6 space-y-4">
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    <div className="h-6 bg-gray-200 rounded w-1/3"></div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => (
              <Card key={item.id} className="overflow-hidden hover:shadow-xl transition-all duration-300 group">
                <div className="relative">
                  <img
                    src={item.image_url || "/placeholder.svg"}
                    alt={item.name}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <Badge className="absolute top-3 left-3 bg-green-600">
                    {calculateDiscount(item.original_price, item.discounted_price)}% OFF
                  </Badge>
                  <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-full text-sm font-medium text-red-600 flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {item.expiry_time}
                  </div>
                  <div className="absolute bottom-3 left-3 bg-orange-600 text-white px-2 py-1 rounded-full text-xs font-medium">
                    {item.city}
                  </div>
                </div>

                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-bold text-lg text-gray-900">{item.name}</h3>
                      <p className="text-gray-600 text-sm flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {item.hotel_name}
                      </p>
                      <p className="text-gray-500 text-xs mt-1 line-clamp-2">{item.description}</p>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span>{item.rating}</span>
                      </div>
                      <span>{item.distance}</span>
                      <Badge variant="secondary" className="text-xs">
                        {item.cuisine}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-2xl font-bold text-green-600">₹{item.discounted_price}</span>
                          <span className="text-sm text-gray-500 line-through">₹{item.original_price}</span>
                        </div>
                        <p className="text-xs text-gray-600">You save ₹{item.original_price - item.discounted_price}</p>
                      </div>

                      <Button
                        size="sm"
                        className={`${addedItems.has(item.id) ? "bg-green-600 hover:bg-green-700" : "bg-orange-600 hover:bg-orange-700"} transition-colors`}
                        onClick={() => handleAddToCart(item)}
                      >
                        {addedItems.has(item.id) ? (
                          <>
                            <Check className="h-4 w-4 mr-1" />
                            Added
                          </>
                        ) : (
                          <>
                            <Plus className="h-4 w-4 mr-1" />
                            Add
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!loading && filteredItems.length === 0 && (
          <div className="text-center py-12">
            <ChefHat className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 text-lg mb-2">No food items found matching your search.</p>
            <p className="text-gray-500 mb-4">Try adjusting your filters or search terms.</p>
            <Button
              onClick={() => {
                setSearchTerm("")
                setSelectedCity("")
                setSelectedCuisine("")
              }}
            >
              Clear All Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
